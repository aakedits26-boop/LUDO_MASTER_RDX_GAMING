# Ludo Master — Android Build Guide

Produced by RDX Gaming

یہ پروجیکٹ Android APK/AAB بنانے کے لیے Capacitor کے ساتھ تیار کیا گیا ہے۔

## ضروری چیزیں
- Windows/Mac/Linux کمپیوٹر
- Node.js LTS
- Android Studio
- Android SDK
- JDK 17

## APK بنانے کے مراحل

1. اس ZIP کو extract کریں۔
2. Terminal/Command Prompt میں project folder کھولیں۔
3. چلائیں:
   npm install
4. پھر:
   npm run build
5. Android project بنائیں:
   npx cap add android
6. Web files Android میں sync کریں:
   npx cap sync android
7. Android Studio کھولیں:
   npx cap open android
8. Android Studio میں Build > Generate App Bundles or APKs سے APK یا signed AAB بنائیں۔

## Play Store
Google Play پر نئی app کے لیے عام طور پر signed Android App Bundle (AAB) استعمال کیا جاتا ہے۔ Play Console account/verification اور Google کی موجودہ testing/publishing requirements بھی پوری کرنی ہوں گی۔

نوٹ: یہ source project ہے؛ یہ ZIP خود APK نہیں ہے۔

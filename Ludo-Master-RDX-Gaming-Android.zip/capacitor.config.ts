import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.rdxgaming.ludomaster',
  appName: 'Ludo Master',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;

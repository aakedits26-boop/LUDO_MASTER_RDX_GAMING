# Ludo Master — Produced by RDX Gaming

یہ پروجیکٹ 2/4/6/8 کھلاڑی، 4 مہرے، Dice، 6 پر دوبارہ باری، Home، Safe cells، Cut، Safe، Magic، Partnership اور Winner detection کے ساتھ تیار کیا گیا ہے۔

## چلانے کا طریقہ
1. Node.js انسٹال کریں۔
2. فولڈر میں Terminal کھولیں۔
3. `npm install`
4. `npm run dev`

## Production build
`npm run build`

## Play Store
یہ ویب project براہ راست Play Store پر upload نہیں ہوتا۔ Android کے لیے اسے Capacitor جیسے Android wrapper میں package کرکے signed AAB بنانا ہوگا، پھر Google Play Console میں upload کیا جائے گا۔
